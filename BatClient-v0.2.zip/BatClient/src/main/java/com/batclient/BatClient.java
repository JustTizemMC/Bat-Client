package com.batclient;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class BatClient implements ClientModInitializer {
    private static final int PURPLE = 0xFFB56CFF;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int RED = 0xFFFF5555;

    private static KeyMapping toggleHudKey;
    private static KeyMapping toggleSprintKey;
    private static KeyMapping togglePlayerAlertsKey;
    private static KeyMapping toggleBlockScanKey;
    private static KeyMapping openGuiKey;

    private static String nearestPlayers = "No players nearby";
    private static List<String> nearbyPlayerLines = List.of();
    private static List<FoundBlock> blockFindings = List.of();
    private static final Map<UUID, Long> lastAlertTick = new HashMap<>();
    private static long lastScanTick;
    private static long tick;
    private static boolean scanRequested;

    @Override
    public void onInitializeClient() {
        BatConfig.load();
        toggleHudKey = key("Toggle BatClient HUD", GLFW.GLFW_KEY_RIGHT_SHIFT);
        toggleSprintKey = key("Toggle Sprint Assist", GLFW.GLFW_KEY_G);
        togglePlayerAlertsKey = key("Toggle Player Alerts", GLFW.GLFW_KEY_H);
        toggleBlockScanKey = key("Toggle Block Scanner", GLFW.GLFW_KEY_J);
        openGuiKey = key("Open BatClient GUI", GLFW.GLFW_KEY_O);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tick++;
            while (toggleHudKey.consumeClick()) { BatConfig.hudEnabled = !BatConfig.hudEnabled; BatConfig.save(); }
            while (toggleSprintKey.consumeClick()) { BatConfig.sprintAssist = !BatConfig.sprintAssist; BatConfig.save(); }
            while (togglePlayerAlertsKey.consumeClick()) { BatConfig.playerAlerts = !BatConfig.playerAlerts; BatConfig.save(); }
            while (toggleBlockScanKey.consumeClick()) { BatConfig.blockScanner = !BatConfig.blockScanner; BatConfig.save(); }
            while (openGuiKey.consumeClick()) client.setScreen(new BatClientScreen());

            if (client.player == null || client.level == null) {
                nearbyPlayerLines = List.of();
                blockFindings = List.of();
                lastAlertTick.clear();
                return;
            }
            if (BatConfig.sprintAssist && client.player.input != null && client.player.input.hasForwardImpulse()
                    && !client.player.isCrouching() && !client.player.isUsingItem()) {
                client.player.setSprinting(true);
            }

            if (BatConfig.playerAlerts) updatePlayers(client);
            else { nearestPlayers = "Player alerts disabled"; nearbyPlayerLines = List.of(); }

            if (BatConfig.blockScanner && (scanRequested || tick - lastScanTick >= 40)) {
                scanRequested = false;
                lastScanTick = tick;
                scanLoadedArea(client);
            }
        });

        HudRenderCallback.EVENT.register((graphics, deltaTracker) -> renderHud(graphics));
        WorldRenderEvents.BEFORE_DEBUG_RENDER.register(BatClient::renderEsp);
    }

    private static KeyMapping key(String name, int keyCode) {
        return KeyBindingHelper.registerKeyBinding(new KeyMapping(
                name, InputConstants.Type.KEYSYM, keyCode, KeyMapping.Category.MISC));
    }

    public static void requestScan() { scanRequested = true; }
    public static List<FoundBlock> getFindings() { return blockFindings; }

    private static void updatePlayers(Minecraft client) {
        Player local = client.player;
        List<Player> nearby = client.level.players().stream()
                .filter(p -> p != local)
                .filter(p -> p.distanceTo(local) <= BatConfig.alertRadius)
                .sorted(Comparator.comparingDouble(p -> p.distanceTo(local)))
                .toList();
        if (nearby.isEmpty()) {
            nearestPlayers = "No players within " + BatConfig.alertRadius + " blocks";
            nearbyPlayerLines = List.of();
            lastAlertTick.keySet().removeIf(id -> client.level.getPlayerByUUID(id) == null);
            return;
        }
        Player closest = nearby.get(0);
        nearestPlayers = nearby.size() + " player(s) | closest: " + closest.getGameProfile().getName()
                + " - " + (int) closest.distanceTo(local) + "b";
        nearbyPlayerLines = nearby.stream().limit(4).map(p -> p.getGameProfile().getName() + "  "
                + (int) p.distanceTo(local) + "b  " + direction(local, p)).toList();

        long cooldown = BatConfig.alertCooldownSeconds * 20L;
        for (Player p : nearby) {
            long previous = lastAlertTick.getOrDefault(p.getUUID(), Long.MIN_VALUE / 2);
            if (tick - previous >= cooldown) {
                client.player.displayClientMessage(Component.literal("§d[BatClient] §fNearby player: §c"
                        + p.getGameProfile().getName() + " §7(" + (int) p.distanceTo(local) + " blocks, "
                        + direction(local, p) + ")"), false);
                lastAlertTick.put(p.getUUID(), tick);
            }
        }
        lastAlertTick.keySet().removeIf(id -> client.level.getPlayerByUUID(id) == null);
    }

    private static String direction(Player from, Player to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double angle = Math.toDegrees(Math.atan2(-dx, dz));
        String[] directions = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return directions[Math.floorMod((int) Math.round(angle / 45.0), 8)];
    }

    private static void scanLoadedArea(Minecraft client) {
        int radius = BatConfig.scanRadius;
        BlockPos center = client.player.blockPosition();
        List<FoundBlock> found = new ArrayList<>();
        BlockPos.betweenClosedStream(center.offset(-radius, -8, -radius), center.offset(radius, 8, radius)).forEach(pos -> {
            if (!client.level.hasChunkAt(pos)) return;
            BlockState state = client.level.getBlockState(pos);
            Block block = state.getBlock();
            String label = null;
            String blockId = BuiltInRegistries.BLOCK.getKey(block).getPath();
            if (block == Blocks.SPAWNER) label = "Spawner";
            else if (isStorageBlock(blockId)) label = "Storage";
            else if (block == Blocks.NETHER_PORTAL || block == Blocks.END_PORTAL || block == Blocks.END_GATEWAY) label = "Portal";
            else if (isPlayerMadeHeuristic(blockId)) label = "Player-made?";
            if (label != null) {
                double distance = Math.sqrt(pos.distToCenterSqr(client.player.position()));
                found.add(new FoundBlock(label, pos.immutable(), distance));
            }
        });
        found.sort(Comparator.comparingDouble(FoundBlock::distance));
        blockFindings = List.copyOf(found);
    }

    private static boolean isStorageBlock(String id) {
        return id.equals("chest") || id.equals("trapped_chest") || id.equals("ender_chest")
                || id.equals("barrel") || id.endsWith("_shulker_box") || id.equals("shulker_box")
                || id.equals("hopper") || id.equals("dispenser") || id.equals("dropper");
    }

    private static boolean isPlayerMadeHeuristic(String id) {
        return id.equals("obsidian") || id.equals("crying_obsidian")
                || id.equals("crafting_table") || id.equals("furnace")
                || id.equals("blast_furnace") || id.equals("smoker")
                || id.equals("anvil") || id.equals("chipped_anvil")
                || id.equals("damaged_anvil") || id.equals("enchanting_table")
                || id.equals("beacon") || id.equals("respawn_anchor")
                || id.equals("lodestone") || id.equals("ender_chest");
    }

    private static void renderEsp(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context) {
        Minecraft mc = Minecraft.getInstance();
        if (!BatConfig.espEnabled || !BatConfig.blockScanner || mc.player == null || mc.level == null || blockFindings.isEmpty()) return;
        Vec3 camera = mc.gameRenderer.getMainCamera().position();
        PoseStack pose = context.matrices();
        VertexConsumer lines = context.consumers().getBuffer(RenderTypes.lines());
        pose.pushPose();
        for (FoundBlock finding : blockFindings) {
            if (!isEspTypeEnabled(finding.type()) || finding.distance() > BatConfig.scanRadius + 1.5) continue;
            int color = BatConfig.colorFor(finding.type());
            float red = ((color >> 16) & 255) / 255.0f;
            float green = ((color >> 8) & 255) / 255.0f;
            float blue = (color & 255) / 255.0f;
            BlockPos pos = finding.pos();
            pose.pushPose();
            pose.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
            LevelRenderer.renderLineBox(pose, lines, new AABB(0.015, 0.015, 0.015, 0.985, 0.985, 0.985), red, green, blue, 0.95f);
            pose.popPose();
        }
        pose.popPose();
    }

    private static boolean isEspTypeEnabled(String type) {
        return switch (type) {
            case "Spawner" -> BatConfig.spawnerEsp;
            case "Storage" -> BatConfig.storageEsp;
            case "Portal" -> BatConfig.portalEsp;
            default -> BatConfig.suspiciousEsp;
        };
    }

    private static void renderHud(GuiGraphics g) {
        if (!BatConfig.hudEnabled) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        int x = 8, y = 8;
        g.fill(x - 4, y - 4, x + 238, y + 142, 0xA5100B18);
        g.fill(x - 4, y - 4, x + 238, y - 2, PURPLE);
        g.drawString(mc.font, "BATCLIENT", x, y, PURPLE, false); y += 13;
        g.drawString(mc.font, "1.21.11  |  FUTURE HUD  |  O: GUI", x, y, 0xFFB9A8C9, false); y += 13;
        g.drawString(mc.font, "Sprint: " + onOff(BatConfig.sprintAssist) + "   ESP: " + onOff(BatConfig.espEnabled), x, y, WHITE, false); y += 12;
        g.drawString(mc.font, "Alerts: " + onOff(BatConfig.playerAlerts) + " (" + BatConfig.alertRadius + "b)", x, y, WHITE, false); y += 12;
        g.drawString(mc.font, nearestPlayers, x, y, RED, false); y += 12;
        for (String line : nearbyPlayerLines) {
            g.drawString(mc.font, line, x + 5, y, 0xFFFFB3B3, false); y += 11;
        }
        g.drawString(mc.font, "Radar: " + blockFindings.size() + " findings | Scan: " + BatConfig.scanRadius + "b", x, y, PURPLE, false); y += 12;
        if (BatConfig.blockScanner) {
            for (FoundBlock finding : blockFindings.stream().limit(3).toList()) {
                g.drawString(mc.font, finding.type() + " @ " + finding.pos().getX() + "," + finding.pos().getY() + "," + finding.pos().getZ(),
                        x, y, BatConfig.colorFor(finding.type()), false);
                y += 11;
            }
        }
    }

    private static String onOff(boolean enabled) { return enabled ? "ON" : "OFF"; }
    public record FoundBlock(String type, BlockPos pos, double distance) {}
}
