package com.batclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;
import java.util.Locale;

/** Future-inspired clickable control panel and searchable local block radar. */
public final class BatClientScreen extends Screen {
    private EditBox searchBox;
    private int scroll;
    private String status = "Local loaded-chunk radar";

    public BatClientScreen() {
        super(Component.literal("BatClient"));
    }

    @Override
    protected void init() {
        clearWidgets();
        int panelLeft = Math.max(12, (width - 430) / 2);
        int panelTop = Math.max(12, (height - 370) / 2);
        int x = panelLeft + 14;
        int y = panelTop + 42;
        int gap = 6;
        int bw = 128;

        addRenderableWidget(Button.builder(label("Sprint Assist", BatConfig.sprintAssist), b -> toggle("sprint")).bounds(x, y, bw, 20).build());
        addRenderableWidget(Button.builder(label("Player Alerts", BatConfig.playerAlerts), b -> toggle("alerts")).bounds(x + bw + gap, y, bw, 20).build());
        addRenderableWidget(Button.builder(label("Block Scanner", BatConfig.blockScanner), b -> toggle("scan")).bounds(x + (bw + gap) * 2, y, bw, 20).build());
        y += 25;
        addRenderableWidget(Button.builder(label("ESP Master", BatConfig.espEnabled), b -> toggle("esp")).bounds(x, y, bw, 20).build());
        addRenderableWidget(Button.builder(label("Spawner ESP", BatConfig.spawnerEsp), b -> toggle("spawner")).bounds(x + bw + gap, y, bw, 20).build());
        addRenderableWidget(Button.builder(label("Storage ESP", BatConfig.storageEsp), b -> toggle("storage")).bounds(x + (bw + gap) * 2, y, bw, 20).build());
        y += 25;
        addRenderableWidget(Button.builder(label("Portal ESP", BatConfig.portalEsp), b -> toggle("portal")).bounds(x, y, bw, 20).build());
        addRenderableWidget(Button.builder(label("Suspicious ESP", BatConfig.suspiciousEsp), b -> toggle("suspicious")).bounds(x + bw + gap, y, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Color: " + colorName()), b -> {
            BatConfig.colorPreset = (BatConfig.colorPreset + 1) % 3;
            BatConfig.save();
            rebuild();
        }).bounds(x + (bw + gap) * 2, y, bw, 20).build());
        y += 28;
        addRenderableWidget(Button.builder(Component.literal("Alert radius -"), b -> changeAlertRadius(-25)).bounds(x, y, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Alert radius +"), b -> changeAlertRadius(25)).bounds(x + 101, y, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Scan radius -"), b -> changeScanRadius(-4)).bounds(x + 202, y, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Scan radius +"), b -> changeScanRadius(4)).bounds(x + 303, y, 95, 20).build());
        y += 26;
        addRenderableWidget(Button.builder(Component.literal("Alert cooldown -"), b -> changeCooldown(-5)).bounds(x, y, 196, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Alert cooldown +"), b -> changeCooldown(5)).bounds(x + 202, y, 196, 20).build());
        y += 26;
        searchBox = new EditBox(font, x, y, 398, 20, Component.literal("Search radar"));
        searchBox.setHint(Component.literal("Search: spawner, storage, portal, player-made..."));
        searchBox.setResponder(value -> scroll = 0);
        addRenderableWidget(searchBox);
        addRenderableWidget(Button.builder(Component.literal("Refresh scan"), b -> {
            BatClient.requestScan();
            status = "Scan refreshed from loaded chunks";
        }).bounds(x, y + 25, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose()).bounds(x + 278, y + 25, 120, 20).build());
    }

    private void toggle(String feature) {
        switch (feature) {
            case "sprint" -> BatConfig.sprintAssist = !BatConfig.sprintAssist;
            case "alerts" -> BatConfig.playerAlerts = !BatConfig.playerAlerts;
            case "scan" -> BatConfig.blockScanner = !BatConfig.blockScanner;
            case "esp" -> BatConfig.espEnabled = !BatConfig.espEnabled;
            case "spawner" -> BatConfig.spawnerEsp = !BatConfig.spawnerEsp;
            case "storage" -> BatConfig.storageEsp = !BatConfig.storageEsp;
            case "portal" -> BatConfig.portalEsp = !BatConfig.portalEsp;
            case "suspicious" -> BatConfig.suspiciousEsp = !BatConfig.suspiciousEsp;
        }
        BatConfig.save();
        rebuild();
    }

    private void changeAlertRadius(int delta) {
        BatConfig.alertRadius = Math.max(25, Math.min(200, BatConfig.alertRadius + delta));
        BatConfig.save(); rebuild();
    }
    private void changeScanRadius(int delta) {
        BatConfig.scanRadius = Math.max(8, Math.min(48, BatConfig.scanRadius + delta));
        BatConfig.save(); BatClient.requestScan(); rebuild();
    }
    private void changeCooldown(int delta) {
        BatConfig.alertCooldownSeconds = Math.max(5, Math.min(300, BatConfig.alertCooldownSeconds + delta));
        BatConfig.save(); rebuild();
    }
    private void rebuild() { clearWidgets(); init(); }
    private static Component label(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }
    private String colorName() { return switch (BatConfig.colorPreset) { case 1 -> "Neon"; case 2 -> "Ice"; default -> "Future"; }; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int left = Math.max(12, (width - 430) / 2);
        int top = Math.max(12, (height - 370) / 2);
        g.fill(0, 0, width, height, 0x9905000C);
        g.fill(left, top, left + 430, top + 370, 0xF0110B1B);
        g.fill(left, top, left + 430, top + 3, 0xFFB56CFF);
        g.drawString(font, "BATCLIENT  /  CONTROL CENTER", left + 14, top + 12, 0xFFB56CFF, false);
        g.drawString(font, "Combat  •  Radar  •  ESP  •  Settings", left + 14, top + 27, 0xFFB9A8C9, false);
        super.render(g, mouseX, mouseY, partialTick);

        int radarTop = top + 244;
        g.drawString(font, "BASE RADAR  |  " + BatClient.getFindings().size() + " loaded-world findings", left + 14, radarTop, 0xFFFFC857, false);
        List<BatClient.FoundBlock> matches = BatClient.getFindings().stream()
                .filter(f -> searchBox == null || searchBox.getValue().isBlank()
                        || (f.type() + " " + f.pos().getX() + " " + f.pos().getY() + " " + f.pos().getZ())
                        .toLowerCase(Locale.ROOT).contains(searchBox.getValue().toLowerCase(Locale.ROOT)))
                .toList();
        int rowY = radarTop + 13;
        for (int i = scroll; i < Math.min(matches.size(), scroll + 4); i++) {
            BatClient.FoundBlock f = matches.get(i);
            String line = f.type() + "  " + f.pos().getX() + ", " + f.pos().getY() + ", " + f.pos().getZ()
                    + "  ·  " + (int) f.distance() + "m";
            g.drawString(font, line, left + 14, rowY, BatConfig.colorFor(f.type()), false);
            rowY += 11;
        }
        if (matches.isEmpty()) g.drawString(font, "No matches in the currently loaded scan area", left + 14, rowY, 0xFFB9A8C9, false);
        g.drawString(font, status + "  |  Alerts: " + BatConfig.alertRadius + "b  |  Scan: " + BatConfig.scanRadius + "b  |  Cooldown: " + BatConfig.alertCooldownSeconds + "s",
                left + 14, top + 355, 0xFFB9A8C9, false);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(Math.max(0, BatClient.getFindings().size() - 1), scroll + (verticalAmount < 0 ? 1 : -1)));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
