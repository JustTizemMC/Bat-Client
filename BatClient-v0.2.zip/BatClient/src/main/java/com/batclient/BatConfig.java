package com.batclient;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Persistent local settings for BatClient. */
public final class BatConfig {
    private BatConfig() {}

    public static boolean hudEnabled = true;
    public static boolean sprintAssist = false;
    public static boolean playerAlerts = true;
    public static boolean blockScanner = true;
    public static boolean espEnabled = true;
    public static boolean spawnerEsp = true;
    public static boolean storageEsp = true;
    public static boolean portalEsp = true;
    public static boolean suspiciousEsp = true;
    public static int alertRadius = 200;
    public static int scanRadius = 24;
    public static int alertCooldownSeconds = 30;
    public static int colorPreset = 0;

    public static int colorFor(String type) {
        if (colorPreset == 1) {
            if (type.equals("Spawner")) return 0xFFFF3DCE;
            if (type.equals("Storage")) return 0xFF39FF88;
            if (type.equals("Portal")) return 0xFF45E8FF;
            return 0xFFFFF04A;
        }
        if (colorPreset == 2) {
            if (type.equals("Spawner")) return 0xFF83A8FF;
            if (type.equals("Storage")) return 0xFF69F0E8;
            if (type.equals("Portal")) return 0xFFC6A7FF;
            return 0xFFE5F4FF;
        }
        if (type.equals("Spawner")) return 0xFFFF5555;
        if (type.equals("Storage")) return 0xFF55D6FF;
        if (type.equals("Portal")) return 0xFFB56CFF;
        return 0xFFFFC857;
    }

    public static void load() {
        Properties p = new Properties();
        Path path = configPath();
        if (!Files.exists(path)) return;
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
            hudEnabled = bool(p, "hudEnabled", hudEnabled);
            sprintAssist = bool(p, "sprintAssist", sprintAssist);
            playerAlerts = bool(p, "playerAlerts", playerAlerts);
            blockScanner = bool(p, "blockScanner", blockScanner);
            espEnabled = bool(p, "espEnabled", espEnabled);
            spawnerEsp = bool(p, "spawnerEsp", spawnerEsp);
            storageEsp = bool(p, "storageEsp", storageEsp);
            portalEsp = bool(p, "portalEsp", portalEsp);
            suspiciousEsp = bool(p, "suspiciousEsp", suspiciousEsp);
            alertRadius = clamp(integer(p, "alertRadius", alertRadius), 25, 200);
            scanRadius = clamp(integer(p, "scanRadius", scanRadius), 8, 48);
            alertCooldownSeconds = clamp(integer(p, "alertCooldownSeconds", alertCooldownSeconds), 5, 300);
            colorPreset = clamp(integer(p, "colorPreset", colorPreset), 0, 2);
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hudEnabled", Boolean.toString(hudEnabled));
        p.setProperty("sprintAssist", Boolean.toString(sprintAssist));
        p.setProperty("playerAlerts", Boolean.toString(playerAlerts));
        p.setProperty("blockScanner", Boolean.toString(blockScanner));
        p.setProperty("espEnabled", Boolean.toString(espEnabled));
        p.setProperty("spawnerEsp", Boolean.toString(spawnerEsp));
        p.setProperty("storageEsp", Boolean.toString(storageEsp));
        p.setProperty("portalEsp", Boolean.toString(portalEsp));
        p.setProperty("suspiciousEsp", Boolean.toString(suspiciousEsp));
        p.setProperty("alertRadius", Integer.toString(alertRadius));
        p.setProperty("scanRadius", Integer.toString(scanRadius));
        p.setProperty("alertCooldownSeconds", Integer.toString(alertCooldownSeconds));
        p.setProperty("colorPreset", Integer.toString(colorPreset));
        Path path = configPath();
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                p.store(out, "BatClient settings");
            }
        } catch (IOException ignored) {
        }
    }

    private static Path configPath() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("batclient.properties");
    }

    private static boolean bool(Properties p, String key, boolean fallback) {
        return Boolean.parseBoolean(p.getProperty(key, Boolean.toString(fallback)));
    }
    private static int integer(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback))); }
        catch (NumberFormatException ignored) { return fallback; }
    }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
}
