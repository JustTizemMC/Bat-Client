# BatClient — Fabric 1.21.11

BatClient is a client-side Minecraft Java utility client for Fabric. It includes a compact Future-inspired HUD, a clickable control center, proximity alerts, a searchable local block radar, and configurable block outlines.

## Features

1. **Visual block ESP outlines** for spawners, storage, portals, and selected player-build blocks. Outlines are rendered for block positions already found by the local scanner.
2. **Searchable base radar** in the click GUI. Search results include block type, coordinates, and distance.
3. **Player proximity alerts** with usernames, distance, compass direction, a configurable radius (25–200 blocks), and per-player cooldown.
4. **Clickable Future-style GUI** opened with `O`, with switches for combat movement, player alerts, scanning, ESP categories, color presets, and a searchable radar.
5. **Configurable settings** for scan radius (8–48 blocks), alert radius (25–200 blocks), alert cooldown (5–300 seconds), ESP categories, and three color presets. Settings are saved to `config/batclient.properties`.

## Hotkeys

- `O`: open BatClient control center
- `Right Shift`: toggle HUD
- `G`: toggle sprint assist
- `H`: toggle player alerts
- `J`: toggle block scanner

## Build

Requires Java 21 and Gradle 8.14+.

```sh
gradle build
```

The remapped mod JAR should be in `build/libs/` after a successful build.

## Install

1. Install Fabric Loader for Minecraft 1.21.11.
2. Install Fabric API for Minecraft 1.21.11.
3. Put the built BatClient JAR into `.minecraft/mods`.

## Compatibility and limitations

- This is a client-only Fabric mod. It cannot guarantee compatibility with every server, proxy, custom protocol, or future Minecraft version.
- Player alerts only detect player entities the server has sent to the client. A 200-block setting is a maximum requested radius, not a guarantee that every player in that radius is tracked or visible.
- The radar and ESP only use blocks in chunks already loaded by the client. They do not reveal unloaded chunks, hidden server data, or protected information.
- The scanner uses block-type heuristics. “Player-made?” findings can be false positives and do not prove that a base exists.
- ESP uses normal depth-tested line rendering; blocks behind opaque terrain are not guaranteed to remain visible.
- Sprint assist only requests ordinary sprinting while moving forward. It does not manipulate packets, bypass anti-cheat, or evade server checks.
- Follow each server's rules. Some servers prohibit client-side radar, ESP, movement changes, or other mods.

This is source code and has not been compiled or tested in a live Minecraft client in this environment. Build it with the steps above before installing it.
